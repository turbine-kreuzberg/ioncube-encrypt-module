                        64 Bit Encoders
                        ---------------

The Linux Encoder package now includes Encoders built for 64 bit. The
32 bit Encoders have always worked on 64 bit systems provided that a 32
bit glibc is installed too, but using a native 64 bit Encoder avoids
this need.

The 64 bit Encoders are suffixed with _64. 64 bit builds for the
legacy obsolete Encoders are not provided.

